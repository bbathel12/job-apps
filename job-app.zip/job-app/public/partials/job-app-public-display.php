<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://github.com/bbathel12
 * @since      1.0.0
 *
 * @package    Job_App
 * @subpackage Job_App/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
