<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://github.com/bbathel12
 * @since      1.0.0
 *
 * @package    Job_App
 * @subpackage Job_App/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
